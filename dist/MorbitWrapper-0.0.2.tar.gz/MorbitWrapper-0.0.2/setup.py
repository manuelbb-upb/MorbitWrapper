# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['morbitwrapper']

package_data = \
{'': ['*']}

install_requires = \
['julia>=0.5.6,<0.6.0', 'numpy>=1.20.2,<2.0.0']

setup_kwargs = {
    'name': 'morbitwrapper',
    'version': '0.0.2',
    'description': 'A wrapper for the Morbit MOP solver written in Julia.',
    'long_description': '# MorbitWrapper\nPython wrapper for Morbit julia module.\nBasic functionalities of the [original module](https://github.com/manuelbb-upb/Morbit) are wrapped and you can refer to the README there for description of the internal parameters.\nNote that the only difference is, that `Δ_0` is the inital trust region radius in Python because it is easier to type.\n\n## Basic usage \nSee the examples subfolder for more involved examples.\n```python\nimport MorbitWrapper as mw\n\n# mw.set_MORBIT_SYS_IMG(None) # deactivate use of a precompiled sysimage, results in slow startup\n\nmop = mw.MOP(lb = [-4, -4], ub =[4,4])\n\ndef f1(x):\n    return (x[0]-1)**2 + (x[1]-1)**2\n    \nf2 = lambda x : (x[0]+1)**2 + (x[1]+1)**2 \ndf2 = lambda x : [ 2*(x[0]+1), 2*(x[1]+1) ]\n\nmop.add_expensive_function(f1)\nmop.add_cheap_function(f2, df2)\n\nconf = mw.AlgoConfig( max_iter = 10, all_objectives_descent = True )\nx, y = mop.optimize([3.14, 4], conf)\n\n# conf.save("results.jld") \n```\n',
    'author': 'Manuel Berkemeier',
    'author_email': 'manuelbb@mail.uni-paderborn.de',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/manuelbb-upb/MorbitWrapper',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
