# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['morbitwrapper']

package_data = \
{'': ['*']}

install_requires = \
['find-libpython>=0.2.0,<0.3.0',
 'julia>=0.5.6,<0.6.0',
 'matplotlib>=3.4.2,<4.0.0',
 'numpy>=1.20.2,<2.0.0']

setup_kwargs = {
    'name': 'morbitwrapper',
    'version': '0.0.2',
    'description': 'A wrapper for the Morbit MOP solver written in Julia.',
    'long_description': '# MorbitWrapper\nPython wrapper for Morbit julia module.\nBasic functionalities of the [original module](https://github.com/manuelbb-upb/Morbit) are wrapped and you \ncan refer to the README and doucmentation of the Julia package for more detailed description of the internal parameters.  \nNote, the Python constructors are written to accept the parameters in a more verbose way: \n`mu` instead of `μ` and `delta_init` instead of `Δ₀`.\n\n## Basic usage \n**There is a folder "examples" with some scripts inside.**\n\n### Wrapper settings \n\nFirst `morbitwrapper` should be imported.\n```python\nimport MorbitWrapper as mw\n```\nThe wrapper needs a working Julia installation, preferably version 1.6+.\nBy default, we assume `julia` to be available in the global `PATH`.\nYou can set an alternative version via\n```python\nmw.set_JULIA_RUNTIME( abspath_to_julia_bin )\n```\nYou can also specify a Julia environment, where `Morbit.jl` is available:\n```python \nmw.set_JULIA_ENV("@v1.6") # if you have Morbit in the default environment of Julia 1.6.x\n```\nIf Morbit is not available in the environment, then the wrapper will try to \n`add` it. \nDepending on the file system permissions this could error.\nThe default setting is `None` which leads to a temporary environment being created.\n\n!!! note \n    Due to Julia being JIT compiled, the initial startup time might be long.\n    To overcome this, a sysimage with `Morbit.jl` and `PyCall` can be compiled.\n    Simply specify `mw.set_MORBIT_SYS_IMG( target_path )`.\n    The creation will take a lot of time (first, a base image has to be compiled \n    and then two sysimage have to be compiled on top of that).  \n    If, at some point the sysimage has to be updated, simply delete the output file.\n    To deactive the image, delete the code snippet or use \n    ```python\n    mw.set_MORBIT_SYS_IMG( None )\n    ```\n    \nThe Julia depot path can be set via `mw.set_JULIA_DEPOT_PATH`. \nThis can be used to setup a self-contained Project environment.\n\nAll setings can be set in a JSON file and then be loaded with `mw.load_settings`.\nA possible settings file could look like this:\n```\n{\n    "JULIA_RUNTIME" : "./julia-1.6.1/bin/julia",\n    "JULIA_DEPOT_PATH" : "./.julia_depot",\n    "JULIA_ENV" : "@v1.6",\n    "MORBIT_SYS_IMG" : "./pycall_morbit.sysimg"\n}\n```\nPaths are interpreted relative to the location of the JSON-file.\n\n### Problem Setup and Optimization\nBelow is a minimal example to solve a box-constrained problem with two \nobjectives, where one objective is considered expensive and the other is cheap:\n\n```python\n\nmop = mw.MOP(lb = [-4.0, -4.0], ub =[4.0,4.0])\n\ndef f1(x):\n    return (x[0]-1)**2 + (x[1]-1)**2\n    \nf2 = lambda x : (x[0]+1)**2 + (x[1]+1)**2 \ndf2 = lambda x : [ 2*(x[0]+1), 2*(x[1]+1) ]\n\nmop.add_rbf_objective(f1)\nmop.add_cheap_objective(f2, grad = df2)\n\nconf = mw.AlgoConfig( max_iter = 10 )\nx, y = mop.optimize([3.14, 4], conf)\n```\n\nFor unconstrained problems the number of variables has to be provided with the keyword\nargument `n_vars`:\n```python\nmop = mw.MOP( nvars = 2 )\n```\n\nA scalar-valued objective functions `func` can be added \nwith the following methods:\n* `mop.add_rbf_objective(func, **kwargs)` for modelling with radial basis functions.\n* `mop.add_lagrange_objective(func, **kwargs)` for modelling with Lagrange polynomials.\n* `mop.add_taylor_objective(func, **kwargs)` for modelling with Taylor polynomials.\n* `mop.add_cheap_objective(func, **kwargs)` to not perform modelling.\n\nThe supported keyword arguments for RBF objectives can be found \nwith `mw.RbfConfig.jl_py_props.values()`. \nSimilarly, there are classes `mw.LagrangeConfig`, `mw.TaylorConfig` and `mw.ExactConfig`.\n\nTo add vector objectives, simply use the `add_rbf_vec_objective` etc.\n**These methods require the `n_out` (number of outputs) keyword argument!**\n\n### Plotting and Iteration Data\nAfter optimization, the problem `mop` contains an interesting Julia object, \n`mop.iterDataObj`. \nSome iteration information is stored and can be retrieved as numpy arrays with \nthe following methods:\n```python\nmop.n_iters()       # number of iterations\nmop.n_evals()       # number of evaluation sites\nmop.eval_sites()    # all evaluation vectors in decision space\nmop.eval_vectors()  # all vectors in objective space\nmop.iter_sites()    # iteration sites in decision space \nmop.iter_vectors()  # iteration vectors in objective space.\n```\nTry the following plotting functions:\n```python \nmop.plot_objectives( objf_indices = None, iter_indices = None, scale = True) \nmop.plot_iterates( dims = [0,1] )\n```',
    'author': 'Manuel Berkemeier',
    'author_email': 'manuelbb@mail.uni-paderborn.de',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/manuelbb-upb/MorbitWrapper',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
